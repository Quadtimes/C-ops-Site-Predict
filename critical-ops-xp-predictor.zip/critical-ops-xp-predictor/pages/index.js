import { useState } from "react";
import GameSelector from "../components/GameSelector";

export default function Home() {
  const [data, setData] = useState({ mode: "Ranked", map: "Bureau", matches: 10, elite: false });
  const [xp, setXp] = useState({ totalXP: 0, level: 0 });

  const handleChange = (field, value) => {
    const updated = { ...data, [field]: value };
    setData(updated);
    calculateXP(updated);
  };

  const calculateXP = ({ mode, matches, elite }) => {
    const baseXP = {
      Ranked: 4000,
      Defuse: 3000,
      Deathmatch: 2000,
      "Gun Game": 1500,
    };

    const bonus = elite ? 1.25 : 1; // 25% boost for Elite Pass
    const xpPerMatch = baseXP[mode] || 2000;
    const totalXP = Math.floor(matches * xpPerMatch * bonus);
    const level = Math.floor(totalXP / 10000); // Assume 10,000 XP per level

    setXp({ totalXP, level });
  };

  return (
    <main className="min-h-screen bg-gray-900 text-white p-8">
      <h1 className="text-3xl font-bold mb-6">Critical Ops XP Predictor</h1>
      <GameSelector onChange={handleChange} />
      <div className="mt-4">
        <label>Matches (1-999):</label>
        <input
          type="number"
          min="1"
          max="999"
          value={data.matches}
          onChange={(e) => handleChange("matches", parseInt(e.target.value))}
          className="w-full p-2 rounded bg-gray-700 text-white"
        />
      </div>
      <div className="mt-4">
        <label className="inline-flex items-center">
          <input
            type="checkbox"
            checked={data.elite}
            onChange={(e) => handleChange("elite", e.target.checked)}
            className="form-checkbox h-5 w-5 text-blue-600"
          />
          <span className="ml-2">Elite Pass Bonus</span>
        </label>
      </div>
      <div className="mt-6 p-4 bg-gray-800 rounded">
        <p><strong>Total XP:</strong> {xp.totalXP}</p>
        <p><strong>Estimated Level:</strong> {xp.level}</p>
      </div>
    </main>
  );
}