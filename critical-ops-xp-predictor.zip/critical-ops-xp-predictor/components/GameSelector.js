const gameModes = ["Ranked", "Defuse", "Deathmatch", "Gun Game"];
const maps = ["Bureau", "Raid", "Plaza", "Legacy", "Canals", "Grounded", "Village", "Port", "Soar", "Castello"];

export default function GameSelector({ onChange }) {
  return (
    <div className="bg-gray-800 p-4 rounded-md space-y-4">
      <select onChange={(e) => onChange("mode", e.target.value)} className="w-full p-2 rounded">
        {gameModes.map((mode) => (
          <option key={mode}>{mode}</option>
        ))}
      </select>
      <select onChange={(e) => onChange("map", e.target.value)} className="w-full p-2 rounded">
        {maps.map((map) => (
          <option key={map}>{map}</option>
        ))}
      </select>
    </div>
  );
}